
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;

#[no_mangle]
pub extern "C" fn plugin_init() {
 let state_dir = PathBuf::from("koh_fx_director_koh_render_gate");

 let _ = fs::create_dir_all(&state_dir);

 let state_file = state_dir.join("KOH_RENDER_GATE_STATE.ini");

 if let Ok(mut file) = OpenOptions::new()
 .create(true)
 .append(true)
 .open(&state_file)
 {
 let _ = writeln!(
 file,
 "# KOH FX Director initialized\nburst_active=0\n"
 );
 }
}
