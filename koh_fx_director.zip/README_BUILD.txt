KOH FX Director A2830 Source Code

Plugin:
- DLL name: koh_fx_director.dll
- Lua module: koh_fx_director
- Plugin ID: koh_fx_director

Build:
cargo build --release --manifest-path plugins/koh_fx_director/Cargo.toml

DLL output:
target/release/koh_fx_director.dll
